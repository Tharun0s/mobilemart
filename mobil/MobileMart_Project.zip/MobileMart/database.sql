CREATE DATABASE IF NOT EXISTS mobilemart;
USE mobilemart;
CREATE TABLE IF NOT EXISTS admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(100) NOT NULL
);
CREATE TABLE IF NOT EXISTS mobiles (
 id INT PRIMARY KEY,
 brand VARCHAR(50) NOT NULL,
 model VARCHAR(100) NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 image VARCHAR(100) DEFAULT ''
);
CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 mobile_id INT NOT NULL,
 model VARCHAR(100) NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL,
 line_total DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS feedback (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL,
 rating INT NOT NULL,
 comments VARCHAR(500),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO admins(username,password) VALUES('admin','admin123') ON DUPLICATE KEY UPDATE username=VALUES(username);
INSERT INTO mobiles(id,brand,model,price,image) VALUES
(1,'Apple','iPhone 16',79900,'phone.svg'),(2,'Apple','iPhone 16 Plus',89900,'phone.svg'),(3,'Apple','iPhone 16 Pro',119900,'phone.svg'),
(4,'Samsung','Galaxy S25',80999,'phone.svg'),(5,'Samsung','Galaxy A56',42999,'phone.svg'),(6,'Samsung','Galaxy M35',19999,'phone.svg'),
(7,'OnePlus','OnePlus 13',69999,'phone.svg'),(8,'OnePlus','Nord 4',29999,'phone.svg'),(9,'OnePlus','Nord CE4 Lite',19999,'phone.svg'),
(10,'Redmi','Note 14 Pro',24999,'phone.svg'),(11,'Redmi','Note 14',17999,'phone.svg'),(12,'Redmi','13 5G',13999,'phone.svg'),
(13,'POCO','X7 Pro',26999,'phone.svg'),(14,'POCO','M7 Pro',14999,'phone.svg'),(15,'POCO','F6',24999,'phone.svg'),
(16,'Realme','GT 7 Pro',59999,'phone.svg'),(17,'Realme','P3 Pro',23999,'phone.svg'),(18,'Realme','Narzo 70',15999,'phone.svg'),
(19,'Vivo','V50',34999,'phone.svg'),(20,'Vivo','T3 Pro',24999,'phone.svg'),(21,'Vivo','Y29',13999,'phone.svg'),
(22,'OPPO','Reno 13',37999,'phone.svg'),(23,'OPPO','A5 Pro',17999,'phone.svg'),(24,'Google Pixel','Pixel 9',79999,'phone.svg'),
(25,'Google Pixel','Pixel 8a',52999,'phone.svg'),(26,'Motorola','Edge 50 Fusion',22999,'phone.svg'),(27,'Motorola','G85 5G',17999,'phone.svg'),
(28,'Nothing','Phone (3a)',23999,'phone.svg'),(29,'iQOO','Neo 10R',26999,'phone.svg'),(30,'iQOO','Z10',19999,'phone.svg')
ON DUPLICATE KEY UPDATE brand=VALUES(brand),model=VALUES(model),price=VALUES(price),image=VALUES(image);
